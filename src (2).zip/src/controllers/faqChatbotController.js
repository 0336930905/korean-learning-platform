const FAQ = require('../models/FAQ');
const Course = require('../models/Course');
const Class = require('../models/class');
const User = require('../models/User');
const Document = require('../models/document');
const ClassTest = require('../models/ClassTest');

class FAQChatbot {
    constructor() {
        this.name = "Korea_AI";
        this.welcomeMessages = [
            "Xin chào! Tôi là Korea_AI - trợ lý tư vấn khóa học tiếng Hàn của bạn! 👋",
            "Chào mừng bạn đến với Korea_DB! Tôi sẽ giúp bạn tìm hiểu về các khóa học tiếng Hàn 🇰🇷",
            "Annyeonghaseyo! Tôi là Korea_AI, sẵn sàng hỗ trợ bạn về mọi thông tin khóa học! ✨"
        ];
        
        this.defaultResponses = [
            "Xin lỗi, tôi chưa hiểu rõ câu hỏi của bạn. Bạn có thể hỏi về **giá khóa học**, **lịch lớp học**, **cách nộp bài tập**, **thông tin giảng viên** hay **cách chấm điểm**! 😊",
            "Hmm, câu hỏi này hơi khó hiểu. Hãy thử hỏi về **đăng ký lớp học**, **bài tập về nhà**, **nộp bài** hoặc **theo dõi tiến độ** nhé! 🤔",
            "Tôi có thể giúp bạn về hệ thống học tập **Korea_DB** - nơi học offline với nộp bài online. Bạn muốn biết gì về **lớp học**, **bài tập**, **chấm điểm** hay **đăng ký khóa học**? 💡"
        ];

        this.greetings = [
            'xin chào', 'chào', 'hello', 'hi', 'annyeong', 'annyeonghaseyo', 
            'chào bạn', 'xin chào bạn', 'korea_ai'
        ];

        this.goodbyes = [
            'tạm biệt', 'bye', 'goodbye', 'chào tạm biệt', 'hẹn gặp lại', 
            'cảm ơn', 'thank you', 'thanks'
        ];
    }

    // Chuẩn hóa text để tìm kiếm
    normalizeText(text) {
        // Kiểm tra nếu text không phải là string
        if (typeof text !== 'string') {
            return '';
        }
        
        return text
            .toLowerCase()
            .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, 'a')
            .replace(/[èéẹẻẽêềếệểễ]/g, 'e')
            .replace(/[ìíịỉĩ]/g, 'i')
            .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, 'o')
            .replace(/[ùúụủũưừứựửữ]/g, 'u')
            .replace(/[ỳýỵỷỹ]/g, 'y')
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9\s]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    // Phân tích ý định của câu hỏi
    analyzeIntent(message) {
        const normalizedMessage = this.normalizeText(message);
        
        // Kiểm tra lời chào - bao gồm cả tiếng Anh
        const greetingPatterns = [
            'xin chao', 'chao', 'hello', 'hi', 'annyeong', 'annyeonghaseyo',
            'chao ban', 'xin chao ban', 'hello korea_ai', 'hi korea_ai',
            'hello korea ai', 'hi korea ai', 'xin chao korea ai', 'xin chao korea_ai'
        ];
        
        const isGreeting = greetingPatterns.some(pattern => {
            const normalized = this.normalizeText(pattern);
            return normalizedMessage === normalized || 
                   normalizedMessage.includes(normalized) && normalizedMessage.length <= normalized.length + 5;
        });
        
        if (isGreeting) {
            return { type: 'greeting', confidence: 1.0 };
        }

        // Kiểm tra lời tạm biệt
        const goodbyePatterns = [
            'tam biet', 'bye', 'goodbye', 'chao tam biet', 'cam on', 'thank you', 'thanks'
        ];
        
        const isGoodbye = goodbyePatterns.some(pattern => {
            const normalized = this.normalizeText(pattern);
            return normalizedMessage === normalized || 
                   normalizedMessage.includes(normalized) && normalizedMessage.length <= normalized.length + 5;
        });
        
        if (isGoodbye) {
            return { type: 'goodbye', confidence: 1.0 };
        }

        // Phân tích category với pattern matching chính xác hơn
        const categoryPatterns = {
            'Học phí': {
                primary: [
                    'gia', 'hoc phi', 'price', 'cost', 'bao nhieu tien', 'phi tien',
                    'gia ca', 'chi phi', 'tien hoc', 'phi hoc', 'gia khoa hoc',
                    'bao nhieu', 'gia bao nhieu', 'phi bao nhieu', 'hoc phi cac khoa hoc',
                    'phi cac khoa hoc', 'hoc phi nhu the nao'
                ],
                secondary: ['thanh toan', 'dong tien', 'tra gop', 'giam gia']
            },
            'Lịch học': {
                primary: [
                    'lich hoc', 'lich', 'thoi gian hoc', 'schedule', 'khi nao hoc',
                    'gio hoc', 'ngay hoc', 'buoi hoc'
                ],
                secondary: ['ca hoc', 'thoi gian']
            },
            'Giảng viên': {
                primary: [
                    'giang vien', 'thay co', 'giao vien', 'teacher', 'thong tin giang vien',
                    'co giao', 'thay giao', 'giang vien lop', 'thay co day', 'giang vien day',
                    'thong tin thay co', 'thong tin giao vien', 'giang vien co kinh nghiem'
                ],
                secondary: ['nguoi day', 'instructor', 'day hoc', 'hoc thay', 'kinh nghiem']
            },
            'Chứng chỉ': {
                primary: [
                    'chung chi', 'certificate', 'bang cap', 'topik', 'xep hang'
                ],
                secondary: ['hoan thanh', 'tot nghiep', 'cap do']
            },
            'Lớp học': {
                primary: [
                    'lop hoc', 'so luong hoc vien', 'bao nhieu hoc vien', 'si so',
                    'hoc vien trong lop', 'co bao nhieu hoc vien'
                ],
                secondary: ['class', 'nhom', 'students']
            },
            'Tuyển sinh': {
                primary: [
                    'dang ky', 'lam sao dang ky', 'cach dang ky', 'muon dang ky',
                    'dang ky hoc', 'tham gia', 'bat dau hoc', 'dang ky khoa hoc'
                ],
                secondary: ['tuyen sinh', 'register', 'tai khoan']
            },
            'Khóa học': {
                primary: [
                    'co nhung khoa nao', 'chuong trinh hoc', 'mon hoc',
                    'cac khoa', 'loai khoa hoc', 'khoa hoc nao', 'thoi gian khoa hoc',
                    'bat dau va ket thuc khoa', 'thoi luong khoa hoc', 'thoi gian bat dau va ket thuc khoa'
                ],
                secondary: ['course', 'curriculum', 'level', 'cap do', 'khoa hoc', 'duration']
            },
            'Bài tập': {
                primary: [
                    'bai tap', 'nop bai', 'homework', 'bai ve nha', 'lam bai',
                    'nop bai tap'
                ],
                secondary: ['assignment', 'submission', 'cham diem']
            },
            'Hỗ trợ': {
                primary: [
                    'ho tro', 'support', 'giup do', 'tro giup', 'ho tro hoc online',
                    'hoc online', 'hoc truc tuyen'
                ],
                secondary: ['online', 'tu van', 'cham soc', 'hotline']
            }
        };

        let bestMatch = { category: null, confidence: 0, primaryScore: 0, exactMatches: 0 };
        
        // Kiểm tra exact matches trước
        for (const [category, patterns] of Object.entries(categoryPatterns)) {
            let primaryScore = 0;
            let secondaryScore = 0;
            let exactMatches = 0;
            
            // Kiểm tra primary patterns với trọng số cao
            for (const pattern of patterns.primary) {
                const normalizedPattern = this.normalizeText(pattern);
                if (normalizedMessage.includes(normalizedPattern)) {
                    primaryScore += 3;
                    // Bonus cho exact match hoặc match toàn bộ pattern
                    if (normalizedMessage === normalizedPattern || 
                        normalizedMessage.indexOf(normalizedPattern) === 0) {
                        exactMatches += 5;
                    }
                }
            }
            
            // Kiểm tra secondary patterns
            for (const pattern of patterns.secondary) {
                const normalizedPattern = this.normalizeText(pattern);
                if (normalizedMessage.includes(normalizedPattern)) {
                    secondaryScore += 1;
                }
            }
            
            const totalScore = primaryScore + secondaryScore + exactMatches;
            
            // Chỉ tính confidence dựa trên patterns có match
            let confidence = 0;
            if (totalScore > 0) {
                const matchedPrimaryPatterns = patterns.primary.filter(pattern => 
                    normalizedMessage.includes(this.normalizeText(pattern))
                ).length;
                const matchedSecondaryPatterns = patterns.secondary.filter(pattern => 
                    normalizedMessage.includes(this.normalizeText(pattern))
                ).length;
                
                const maxMatchableScore = (matchedPrimaryPatterns * 3) + matchedSecondaryPatterns + (exactMatches > 0 ? 5 : 0);
                confidence = totalScore / Math.max(maxMatchableScore, 1);
            }
            
            // Cập nhật best match - ưu tiên exact matches
            if (exactMatches > bestMatch.exactMatches || 
                (exactMatches === bestMatch.exactMatches && primaryScore > bestMatch.primaryScore) ||
                (exactMatches === bestMatch.exactMatches && primaryScore === bestMatch.primaryScore && confidence > bestMatch.confidence)) {
                bestMatch = { category, confidence, primaryScore, totalScore, exactMatches };
            }
        }

        // Chỉ trả về kết quả nếu có primary match hoặc confidence đủ cao và có match thực sự
        if (bestMatch.primaryScore > 0 || (bestMatch.confidence > 0.5 && bestMatch.totalScore > 0)) {
            return { 
                type: 'question', 
                category: bestMatch.category, 
                confidence: bestMatch.confidence 
            };
        }

        // Trường hợp unclear - câu hỏi không rõ ràng
        return { 
            type: 'unclear', 
            category: null, 
            confidence: 0 
        };
    }

    // Tìm kiếm FAQ phù hợp và truy cập database thực tế
    async searchFAQ(message, intent) {
        try {
            console.log('🔍 [DEBUG] searchFAQ called with:', { message, intent });
            
            const normalizedQuery = this.normalizeText(message);
            let faqs = [];
            let realData = null;

            // Tìm kiếm trong FAQ database trước
            if (intent.category) {
                console.log('🔍 [DEBUG] Searching FAQs by category:', intent.category);
                faqs = await FAQ.find({ 
                    category: intent.category,
                    isActive: true
                }).sort({ priority: -1, viewCount: -1 }).limit(3);
                console.log('🔍 [DEBUG] Found FAQs by category:', faqs.length);
            }

            // Nếu không tìm thấy FAQ hoặc cần thông tin thực tế, truy cập database
            if (faqs.length === 0 || intent.category) {
                console.log('🔍 [DEBUG] Getting real database info...');
                realData = await this.getRealDatabaseInfo(message, intent);
                console.log('🔍 [DEBUG] Real data result:', !!realData);
            }

            // Fallback: tìm kiếm text search nếu chưa có kết quả
            if (faqs.length === 0 && !realData) {
                console.log('🔍 [DEBUG] Trying advanced FAQ search...');
                
                // Tìm kiếm nâng cao trong FAQs theo nhiều cách
                try {
                    // 1. Tìm kiếm full text
                    faqs = await FAQ.find({
                        $text: { $search: normalizedQuery },
                        isActive: true
                    }).sort({ score: { $meta: 'textScore' }, viewCount: -1, priority: -1 }).limit(5);
                    console.log('🔍 [DEBUG] Full text search results:', faqs.length);
                } catch (textSearchError) {
                    console.log('🔍 [DEBUG] Full text search failed, trying keyword search...');
                }
                
                // 2. Nếu chưa có kết quả, tìm theo keywords
                if (faqs.length === 0) {
                    const keywords = normalizedQuery.split(' ').filter(word => word.length > 2);
                    if (keywords.length > 0) {
                        faqs = await FAQ.find({
                            $or: [
                                { question: { $regex: keywords.join('|'), $options: 'i' } },
                                { answer: { $regex: keywords.join('|'), $options: 'i' } },
                                { keywords: { $in: keywords } }
                            ],
                            isActive: true
                        }).sort({ viewCount: -1, priority: -1 }).limit(5);
                        console.log('🔍 [DEBUG] Keyword search results:', faqs.length);
                    }
                }
                
                // 3. Tìm kiếm từng từ riêng lẻ
                if (faqs.length === 0) {
                    const words = normalizedQuery.split(' ');
                    for (const word of words) {
                        if (word.length > 2) {
                            const wordResults = await FAQ.find({
                                $or: [
                                    { question: { $regex: word, $options: 'i' } },
                                    { answer: { $regex: word, $options: 'i' } }
                                ],
                                isActive: true
                            }).sort({ viewCount: -1, priority: -1 }).limit(3);
                            
                            if (wordResults.length > 0) {
                                faqs = wordResults;
                                console.log(`🔍 [DEBUG] Found results for word "${word}":`, faqs.length);
                                break;
                            }
                        }
                    }
                }
            }

            // Final fallback: get any active FAQs
            if (faqs.length === 0 && !realData) {
                console.log('🔍 [DEBUG] Getting popular FAQs as fallback...');
                faqs = await FAQ.find({ isActive: true })
                    .sort({ viewCount: -1, priority: -1 })
                    .limit(3);
                console.log('🔍 [DEBUG] Fallback FAQs:', faqs.length);
            }

            return { faqs, realData };
        } catch (error) {
            console.error('❌ [ERROR] Error in searchFAQ:', {
                error: error.message,
                stack: error.stack,
                message,
                intent
            });
            
            // Emergency fallback
            try {
                const fallbackFAQs = await FAQ.find({ isActive: true }).limit(3);
                return { faqs: fallbackFAQs, realData: null };
            } catch (fallbackError) {
                console.error('❌ [ERROR] Even fallback failed:', fallbackError);
                return { faqs: [], realData: null };
            }
        }
    }

    // Lấy thông tin thực tế từ database
    async getRealDatabaseInfo(message, intent) {
        try {
            console.log('🔍 [DEBUG] getRealDatabaseInfo called:', { message, intent });
            
            // Đảm bảo message là string
            const normalizedMessage = this.normalizeText(message || '');
            console.log('🔍 [DEBUG] Normalized message:', normalizedMessage);
            
            const categories = intent.categories || [intent.category];
            console.log('🔍 [DEBUG] Categories to check:', categories);
            
            for (const category of categories) {
                console.log(`🔍 [DEBUG] Checking category: ${category}`);
                
                switch (category) {
                    case 'Học phí':
                        if (normalizedMessage.includes('gia') || normalizedMessage.includes('price') || normalizedMessage.includes('cost') || normalizedMessage.includes('hoc phi') || normalizedMessage.includes('tien')) {
                            console.log('🔍 [DEBUG] Querying courses for pricing...');
                            const courses = await Course.find({ status: 'active' })
                                .populate('instructor', 'fullName')
                                .select('title description price duration level category')
                                .limit(5);
                            console.log('🔍 [DEBUG] Found courses:', courses.length);
                            return { type: 'course_pricing', data: courses };
                        }
                        break;

                    case 'Lịch học':
                        if (normalizedMessage.includes('lich') || normalizedMessage.includes('schedule') || normalizedMessage.includes('linh hoat')) {
                            console.log('🔍 [DEBUG] Querying classes for schedule...');
                            const classes = await Class.find({ status: 'active' })
                                .populate('teacher', 'fullName')
                                .populate('course', 'title')
                                .limit(3);
                            console.log('🔍 [DEBUG] Found classes:', classes.length);
                            return { type: 'class_schedule', data: classes };
                        }
                        break;

                    case 'Lớp học':
                        if (normalizedMessage.includes('so luong') || normalizedMessage.includes('hoc vien') || normalizedMessage.includes('students')) {
                            console.log('🔍 [DEBUG] Querying classes for capacity...');
                            const classes = await Class.find({ status: 'active' })
                                .populate('course', 'title')
                                .populate('students', 'fullName email')
                                .limit(3);
                            console.log('🔍 [DEBUG] Found classes:', classes.length);
                            return { type: 'class_capacity', data: classes };
                        }
                        
                        if (normalizedMessage.includes('tai lieu') || normalizedMessage.includes('document') || normalizedMessage.includes('file')) {
                            console.log('🔍 [DEBUG] Querying documents for classes...');
                            const documents = await Document.find({})
                                .populate('class', 'name')
                                .populate('uploadedBy', 'fullName')
                                .limit(10);
                            console.log('🔍 [DEBUG] Found documents:', documents.length);
                            return { type: 'class_documents', data: documents };
                        }
                        
                        if (normalizedMessage.includes('kiem tra') || normalizedMessage.includes('diem') || normalizedMessage.includes('test') || normalizedMessage.includes('score')) {
                            console.log('🔍 [DEBUG] Querying class tests and scores...');
                            const tests = await ClassTest.find({})
                                .populate('class', 'name')
                                .populate('scores.student', 'fullName')
                                .populate('createdBy', 'fullName')
                                .limit(5);
                            console.log('🔍 [DEBUG] Found tests:', tests.length);
                            return { type: 'class_tests', data: tests };
                        }
                        
                        if (normalizedMessage.includes('bai tap') || normalizedMessage.includes('assignment') || normalizedMessage.includes('homework')) {
                            console.log('🔍 [DEBUG] Querying assignments...');
                            try {
                                const Assignment = require('../models/Assignment');
                                const Submission = require('../models/submission');
                                
                                const assignments = await Assignment.find({})
                                    .populate('class', 'name')
                                    .populate('createdBy', 'fullName')
                                    .limit(10);
                                
                                // Lấy thống kê submissions cho mỗi assignment
                                for (let assignment of assignments) {
                                    const submissions = await Submission.find({ assignment: assignment._id });
                                    const gradedSubmissions = submissions.filter(s => s.status === 'graded');
                                    assignment.submissionStats = {
                                        totalSubmissions: submissions.length,
                                        gradedSubmissions: gradedSubmissions.length,
                                        averageScore: gradedSubmissions.length > 0 
                                            ? gradedSubmissions.reduce((sum, s) => sum + (s.grade?.score || 0), 0) / gradedSubmissions.length 
                                            : 0
                                    };
                                }
                                
                                console.log('🔍 [DEBUG] Found assignments:', assignments.length);
                                return { type: 'assignments_info', data: assignments };
                            } catch (assignmentError) {
                                console.log('⚠️ [WARNING] Assignment model error, using fallback');
                                return null;
                            }
                        }
                        break;

                    case 'Giảng viên':
                        if (normalizedMessage.includes('thong tin') || normalizedMessage.includes('giang vien') || normalizedMessage.includes('teacher') || normalizedMessage.includes('thay') || normalizedMessage.includes('co giao')) {
                            console.log('🔍 [DEBUG] Querying teachers with detailed info...');
                            const teachers = await User.find({ role: 'teacher', isActive: true })
                                .select('fullName koreanLevel profileImage email phone dateOfBirth gender averageScore')
                                .limit(5);
                            console.log('🔍 [DEBUG] Found teachers:', teachers.length);
                            
                            // Lấy thêm thông tin về các khóa học mà giảng viên đang dạy
                            const teacherIds = teachers.map(teacher => teacher._id);
                            const courses = await Course.find({ 
                                instructor: { $in: teacherIds }, 
                                status: 'active' 
                            })
                                .populate('instructor', 'fullName')
                                .select('title duration level category price instructor')
                                .limit(10);
                            console.log('🔍 [DEBUG] Found courses by teachers:', courses.length);
                            
                            return { 
                                type: 'teachers_detailed_info', 
                                data: { teachers, courses } 
                            };
                        }
                        break;

                    case 'Khóa học':
                        if (normalizedMessage.includes('level') || normalizedMessage.includes('cap do') || normalizedMessage.includes('category')) {
                            console.log('🔍 [DEBUG] Querying courses...');
                            const courses = await Course.find({ status: 'active' })
                                .populate('instructor', 'fullName')
                                .limit(5);
                            console.log('🔍 [DEBUG] Found courses:', courses.length);
                            return { type: 'courses_info', data: courses };
                        }
                        break;

                    case 'Tuyển sinh':
                        if (normalizedMessage.includes('dang ky') || normalizedMessage.includes('tai khoan') || normalizedMessage.includes('register') || normalizedMessage.includes('tao tai khoan') || normalizedMessage.includes('lap tai khoan')) {
                            console.log('🔍 [DEBUG] Returning registration info...');
                            return { type: 'registration_info', data: { loginUrl: 'http://localhost:3996/login' } };
                        }
                        break;
                }
            }

            console.log('🔍 [DEBUG] No matching category found, returning null');
            return null;
        } catch (error) {
            console.error('❌ [ERROR] Error in getRealDatabaseInfo:', {
                error: error.message,
                stack: error.stack,
                message,
                intent
            });
            return null;
        }
    }

    // Tạo response từ dữ liệu thực tế trong database
    generateRealDataResponse(realData) {
        try {
            switch (realData.type) {
                case 'course_pricing':
                    if (realData.data && realData.data.length > 0) {
                        let response = "💰 **Thông tin học phí các khóa học hiện tại:**\n\n";
                        realData.data.forEach((course, index) => {
                            const price = course.price ? course.price.toLocaleString('vi-VN') + ' VND' : 'Liên hệ để biết giá';
                            response += `**${index + 1}. ${course.title}**\n`;
                            response += `   💵 Học phí: ${price}\n`;
                            if (course.duration) response += `   ⏱️ Thời lượng: ${course.duration}\n`;
                            if (course.level) {
                                const levelDisplay = course.level === 'beginner' ? 'Sơ cấp' : 
                                                   course.level === 'intermediate' ? 'Trung cấp' : 'Nâng cao';
                                response += `   📊 Trình độ: ${levelDisplay}\n`;
                            }
                            if (course.category) response += `   📚 Danh mục: ${course.category}\n`;
                            response += '\n';
                        });
                        response += "📞 *Liên hệ để được tư vấn chi tiết về học phí và chương trình học*";
                        return response;
                    }
                    break;

                case 'class_schedule':
                    if (realData.data && realData.data.length > 0) {
                        let response = "📅 **Lịch học các lớp đang hoạt động:**\n\n";
                        realData.data.forEach((classItem, index) => {
                            response += `**${index + 1}. ${classItem.course?.title || classItem.className}**\n`;
                            response += `   👨‍🏫 Giảng viên: ${classItem.teacher?.fullName || 'Chưa phân công'}\n`;
                            if (classItem.schedule) response += `   🕐 Lịch học: ${classItem.schedule}\n`;
                            if (classItem.startDate) response += `   📆 Ngày bắt đầu: ${new Date(classItem.startDate).toLocaleDateString('vi-VN')}\n`;
                            response += '\n';
                        });
                        response += "📲 *Liên hệ để được tư vấn lịch học phù hợp*";
                        return response;
                    }
                    break;

                case 'class_capacity':
                    if (realData.data && realData.data.length > 0) {
                        let response = "👥 **Thông tin sĩ số các lớp học:**\n\n";
                        realData.data.forEach((classItem, index) => {
                            const currentStudents = classItem.students?.length || 0;
                            response += `**${index + 1}. ${classItem.course?.title || classItem.className}**\n`;
                            response += `   👥 Sĩ số hiện tại: ${currentStudents}/${classItem.maxStudents || 'Không giới hạn'} học viên\n`;
                            if (classItem.startDate) response += `   📅 Bắt đầu: ${new Date(classItem.startDate).toLocaleDateString('vi-VN')}\n`;
                            response += '\n';
                        });
                        response += "🎯 *Lớp học nhỏ đảm bảo chất lượng giảng dạy tốt nhất*";
                        return response;
                    }
                    break;

                case 'teachers_detailed_info':
                    if (realData.data && realData.data.teachers && realData.data.teachers.length > 0) {
                        let response = "👨‍🏫 **Thông tin chi tiết đội ngũ giảng viên:**\n\n";
                        
                        realData.data.teachers.forEach((teacher, index) => {
                            response += `**${index + 1}. Thầy/Cô ${teacher.fullName}**\n`;
                            
                            // Thông tin cơ bản
                            if (teacher.koreanLevel) {
                                response += `   🏆 Chứng chỉ tiếng Hàn: ${teacher.koreanLevel}\n`;
                            }
                            if (teacher.email) {
                                response += `   📧 Email: ${teacher.email}\n`;
                            }
                            if (teacher.phone) {
                                response += `   📞 Điện thoại: ${teacher.phone}\n`;
                            }
                            if (teacher.averageScore && teacher.averageScore > 0) {
                                response += `   ⭐ Đánh giá trung bình: ${teacher.averageScore.toFixed(1)}/10\n`;
                            }
                            
                            // Thông tin về các khóa học đang dạy
                            const teacherCourses = realData.data.courses.filter(course => 
                                course.instructor && course.instructor._id.toString() === teacher._id.toString()
                            );
                            
                            if (teacherCourses.length > 0) {
                                response += `   📚 **Khóa học đang giảng dạy:**\n`;
                                teacherCourses.forEach(course => {
                                    const levelDisplay = course.level === 'beginner' ? 'Sơ cấp' : 
                                                       course.level === 'intermediate' ? 'Trung cấp' : 'Nâng cao';
                                    response += `      • ${course.title} (${levelDisplay}) - ${course.duration}\n`;
                                    response += `        💰 ${course.price?.toLocaleString('vi-VN')} VND | 📂 ${course.category}\n`;
                                });
                            }
                            
                            response += `   ✅ Giảng viên chính thức với kinh nghiệm sâu\n`;
                            response += `   🎯 Chuyên môn về ngôn ngữ và văn hóa Hàn Quốc\n\n`;
                        });
                        
                        response += "🌟 **Cam kết chất lượng:**\n";
                        response += "• Đội ngũ giảng viên được tuyển chọn kỹ lưỡng\n";
                        response += "• Có chứng chỉ TOPIK cao cấp và kinh nghiệm thực tế\n";
                        response += "• Phương pháp giảng dạy hiện đại, tương tác cao\n";
                        response += "• Hỗ trợ học viên tận tình 24/7\n\n";
                        response += "👥 *Học trực tiếp với giảng viên chuyên nghiệp, đạt hiệu quả cao nhất!*";
                        return response;
                    }
                    break;

                case 'teachers_info':
                    if (realData.data && realData.data.length > 0) {
                        let response = "👨‍🏫 **Đội ngũ giảng viên chuyên nghiệp:**\n\n";
                        response += "Tại Korea_DB, chúng tôi có đội ngũ giảng viên chất lượng cao:\n\n";
                        realData.data.forEach((teacher, index) => {
                            response += `**${index + 1}. Thầy/Cô ${teacher.fullName}**\n`;
                            if (teacher.koreanLevel) {
                                response += `   🏆 Chứng chỉ tiếng Hàn: ${teacher.koreanLevel}\n`;
                            }
                            response += `   ✅ Giảng viên chính thức với kinh nghiệm giảng dạy\n`;
                            response += `   📚 Chuyên môn sâu về ngôn ngữ và văn hóa Hàn Quốc\n`;
                            response += '\n';
                        });
                        response += "🌟 **Đặc điểm nổi bật:**\n";
                        response += "• Giảng viên được đào tạo bài bản\n";
                        response += "• Có chứng chỉ TOPIK cao cấp\n";
                        response += "• Phương pháp giảng dạy hiện đại và hiệu quả\n";
                        response += "• Nhiệt tình hỗ trợ học viên 24/7\n\n";
                        response += "👥 *Bạn sẽ được học trực tiếp với các thầy cô giàu kinh nghiệm!*";
                        return response;
                    }
                    break;

                case 'courses_info':
                    if (realData.data && realData.data.length > 0) {
                        let response = "📚 **Danh sách các khóa học hiện có:**\n\n";
                        realData.data.forEach((course, index) => {
                            response += `**${index + 1}. ${course.title}**\n`;
                            if (course.description) response += `   📝 ${course.description.substring(0, 80)}...\n`;
                            if (course.level) response += `   📊 Trình độ: ${course.level}\n`;
                            if (course.instructor) response += `   👨‍🏫 Giảng viên: ${course.instructor.fullName}\n`;
                            response += '\n';
                        });
                        response += "🎓 *Đăng ký ngay để bắt đầu hành trình học tiếng Hàn*";
                        return response;
                    }
                    break;

                case 'registration_info':
                    if (realData.data && realData.data.loginUrl) {
                        let response = "🎓 **Đăng ký tài khoản học tiếng Hàn tại Korea_DB:**\n\n";
                        response += "✅ **Cách đăng ký:**\n";
                        response += "1. Truy cập link đăng ký: " + realData.data.loginUrl + "\n";
                        response += "2. Chọn 'Đăng ký tài khoản mới'\n";
                        response += "3. Điền thông tin cá nhân\n";
                        response += "4. Xác nhận email\n";
                        response += "5. Bắt đầu học ngay!\n\n";
                        response += "🌟 **Lợi ích khi đăng ký:**\n";
                        response += "• Truy cập đầy đủ các khóa học tiếng Hàn\n";
                        response += "• Học offline tại lớp với giảng viên chuyên nghiệp\n";
                        response += "• Nộp bài tập và theo dõi tiến độ online\n";
                        response += "• Hỗ trợ 24/7 từ đội ngũ tư vấn\n";
                        response += "• Chứng chỉ hoàn thành khóa học\n\n";
                        response += "📞 *Liên hệ ngay để được tư vấn miễn phí!*";
                        return response;
                    }
                    break;

                case 'class_documents':
                    if (realData.data && realData.data.length > 0) {
                        let response = "📄 **Tài liệu học tập các lớp:**\n\n";
                        
                        // Nhóm tài liệu theo lớp
                        const documentsByClass = {};
                        realData.data.forEach(doc => {
                            const className = doc.class?.name || 'Lớp khác';
                            if (!documentsByClass[className]) {
                                documentsByClass[className] = [];
                            }
                            documentsByClass[className].push(doc);
                        });

                        Object.keys(documentsByClass).forEach((className, index) => {
                            response += `**${index + 1}. ${className}:**\n`;
                            documentsByClass[className].forEach((doc, docIndex) => {
                                const categoryIcon = {
                                    'speaking': '🗣️',
                                    'listening': '👂',
                                    'writing': '✍️',
                                    'vocabulary': '📚'
                                };
                                response += `   ${categoryIcon[doc.category] || '📄'} ${doc.title}\n`;
                                if (doc.description) response += `      📝 ${doc.description.substring(0, 60)}...\n`;
                                response += `      👤 Upload bởi: ${doc.uploadedBy?.fullName || 'Giảng viên'}\n`;
                            });
                            response += '\n';
                        });
                        
                        response += "📥 **Cách truy cập tài liệu:**\n";
                        response += "• Đăng nhập vào hệ thống\n";
                        response += "• Vào phần 'Lớp học của tôi'\n";
                        response += "• Chọn mục 'Tài liệu'\n";
                        response += "• Tải về và học tập\n\n";
                        response += "📚 *Tài liệu được cập nhật thường xuyên để hỗ trợ học tập tốt nhất!*";
                        return response;
                    }
                    break;

                case 'class_tests':
                    if (realData.data && realData.data.length > 0) {
                        let response = "📝 **Kết quả kiểm tra các lớp học:**\n\n";
                        
                        realData.data.forEach((test, index) => {
                            response += `**${index + 1}. ${test.testName}**\n`;
                            response += `   🏫 Lớp: ${test.class?.name || 'Không xác định'}\n`;
                            response += `   📅 Ngày thi: ${new Date(test.testDate).toLocaleDateString('vi-VN')}\n`;
                            response += `   🎯 Điểm tối đa: ${test.maxScore}\n`;
                            response += `   👨‍🏫 Tạo bởi: ${test.createdBy?.fullName || 'Giảng viên'}\n`;
                            
                            if (test.scores && test.scores.length > 0) {
                                // Tính điểm trung bình
                                const avgScore = test.scores.reduce((sum, score) => sum + score.score, 0) / test.scores.length;
                                response += `   📊 Điểm trung bình: ${avgScore.toFixed(1)}/${test.maxScore}\n`;
                                response += `   👥 Số học viên đã thi: ${test.scores.length}\n`;
                                
                                // Hiển thị một vài điểm cao nhất
                                const topScores = test.scores
                                    .sort((a, b) => b.score - a.score)
                                    .slice(0, 3);
                                    
                                response += `   🏆 **Top điểm cao:**\n`;
                                topScores.forEach((score, scoreIndex) => {
                                    response += `      ${scoreIndex + 1}. ${score.student?.fullName}: ${score.score}/${test.maxScore}\n`;
                                });
                            }
                            response += '\n';
                        });
                        
                        response += "📈 **Hệ thống chấm điểm:**\n";
                        response += "• Điểm số được chấm và feedback chi tiết\n";
                        response += "• Theo dõi tiến độ học tập cá nhân\n";
                        response += "• Báo cáo định kỳ gửi phụ huynh\n";
                        response += "• Hỗ trợ ôn tập các điểm yếu\n\n";
                        response += "🎯 *Chất lượng giảng dạy được đánh giá qua kết quả kiểm tra thực tế!*";
                        return response;
                    }
                    break;

                case 'assignments_info':
                    if (realData.data && realData.data.length > 0) {
                        let response = "📚 **Danh sách bài tập về nhà:**\n\n";
                        
                        realData.data.forEach((assignment, index) => {
                            response += `**${index + 1}. ${assignment.title}**\n`;
                            response += `   🏫 Lớp: ${assignment.class?.name || 'Không xác định'}\n`;
                            response += `   📝 Mô tả: ${assignment.description?.substring(0, 60)}...\n`;
                            response += `   📅 Hạn nộp: ${new Date(assignment.dueDate).toLocaleDateString('vi-VN')}\n`;
                            response += `   🎯 Điểm tối đa: ${assignment.maxScore}\n`;
                            response += `   👨‍🏫 Giao bởi: ${assignment.createdBy?.fullName || 'Giảng viên'}\n`;
                            
                            if (assignment.submissionStats) {
                                response += `   📊 Thống kê:\n`;
                                response += `      📤 Số bài nộp: ${assignment.submissionStats.totalSubmissions}\n`;
                                response += `      ✅ Đã chấm: ${assignment.submissionStats.gradedSubmissions}\n`;
                                if (assignment.submissionStats.averageScore > 0) {
                                    response += `      📈 Điểm TB: ${assignment.submissionStats.averageScore.toFixed(1)}/${assignment.maxScore}\n`;
                                }
                            }
                            
                            const status = new Date() > new Date(assignment.dueDate) ? '🔴 Đã hết hạn' : '🟢 Còn hạn';
                            response += `   ${status}\n\n`;
                        });
                        
                        response += "📋 **Hướng dẫn nộp bài:**\n";
                        response += "• Đăng nhập vào hệ thống\n";
                        response += "• Vào mục 'Bài tập của tôi'\n";
                        response += "• Chọn bài tập cần nộp\n";
                        response += "• Upload file và submit\n\n";
                        response += "⏰ *Lưu ý: Nộp đúng hạn để đạt điểm tối đa!*";
                        return response;
                    }
                    break;
            }
            return null;
        } catch (error) {
            console.error('Error generating real data response:', error);
            return null;
        }
    }

    // Tạo response chính
    generateResponse(faqs, intent, originalMessage, realData = null) {
        // Đảm bảo faqs là array
        faqs = Array.isArray(faqs) ? faqs : [];
        
        if (intent.type === 'greeting') {
            const welcome = this.welcomeMessages[Math.floor(Math.random() * this.welcomeMessages.length)];
            return {
                type: 'greeting',
                message: welcome,
                suggestions: this.generateSuggestions([])
            };
        }

        if (intent.type === 'goodbye') {
            return {
                type: 'goodbye',
                message: "Cảm ơn bạn đã sử dụng dịch vụ tư vấn! Chúc bạn học tiếng Hàn vui vẻ! 안녕히 가세요! 👋✨",
                suggestions: ["Giới thiệu về Korea_DB", "Các khóa học hiện có", "Cách đăng ký học"]
            };
        }

        // Xử lý trường hợp unclear - hỏi lại để làm rõ
        if (intent.type === 'unclear') {
            return {
                type: 'clarification',
                message: "🤔 Tôi chưa hiểu rõ câu hỏi của bạn. Bạn có thể hỏi cụ thể hơn được không?\n\n" +
                        "💡 **Ví dụ các câu hỏi tôi có thể trả lời:**\n" +
                        "• \"Giá khóa học tiếng Hàn bao nhiêu?\"\n" +
                        "• \"Lịch học các lớp như thế nào?\"\n" +
                        "• \"Thông tin về giảng viên?\"\n" +
                        "• \"Làm sao để đăng ký học?\"\n\n" +
                        "📝 *Hãy hỏi câu hỏi cụ thể để tôi có thể hỗ trợ bạn tốt nhất!*",
                suggestions: [
                    "💰 Giá các khóa học?",
                    "📅 Lịch học như thế nào?", 
                    "👨‍🏫 Thông tin giảng viên?",
                    "🎓 Cách đăng ký học?"
                ]
            };
        }

        // Ưu tiên thông tin thực tế từ database khi có category rõ ràng
        if (realData && intent.category) {
            const realResponse = this.generateRealDataResponse(realData);
            if (realResponse) {
                return {
                    type: 'database_answer',
                    message: realResponse,
                    suggestions: this.generateSuggestions(faqs),
                    source: 'real_database',
                    category: intent.category
                };
            }
        }

        // Xử lý FAQ với ưu tiên chính xác
        if (faqs.length > 0 && intent.category) {
            let response = "🤖 **Korea_AI trả lời:**\n\n";
            
            if (faqs.length === 1) {
                // Tăng view count
                faqs[0].incrementViewCount();
                response += `**${faqs[0].question}**\n\n`;
                response += `${faqs[0].answer}\n\n`;
                response += `📂 *Danh mục: ${faqs[0].category}*`;
            } else {
                // Hiển thị FAQ phù hợp nhất theo category
                const relevantFAQs = faqs.filter(faq => faq.category === intent.category);
                if (relevantFAQs.length > 0) {
                    response += `Tôi tìm thấy **${relevantFAQs.length}** thông tin về **${intent.category}**:\n\n`;
                    relevantFAQs.forEach((faq, index) => {
                        faq.incrementViewCount();
                        response += `**${index + 1}. ${faq.question}**\n`;
                        response += `${faq.answer}\n\n`;
                    });
                } else {
                    response += "Tôi tìm thấy một số thông tin có thể hữu ích:\n\n";
                    faqs.slice(0, 2).forEach((faq, index) => {
                        faq.incrementViewCount();
                        response += `**${index + 1}. ${faq.question}**\n`;
                        response += `${faq.answer.substring(0, 150)}...\n\n`;
                    });
                }
            }

            return {
                type: 'answer',
                message: response,
                suggestions: this.generateSuggestions(faqs),
                category: intent.category,
                faqs: faqs.map(faq => ({
                    id: faq._id,
                    question: faq.question,
                    answer: faq.answer,
                    category: faq.category
                }))
            };
        }

        // Xử lý FAQ khi không có category rõ ràng nhưng có FAQ results
        if (faqs.length > 0) {
            // Tăng view count cho FAQs được hiển thị
            faqs.forEach(faq => faq.incrementViewCount());
            
            let response = "🤖 **Korea_AI tìm thấy thông tin có thể hữu ích:**\n\n";
            
            if (faqs.length === 1) {
                response += `**${faqs[0].question}**\n\n`;
                response += `${faqs[0].answer}\n\n`;
                response += `📂 *Danh mục: ${faqs[0].category}*`;
            } else {
                response += `Tôi tìm thấy **${faqs.length}** thông tin liên quan:\n\n`;
                faqs.slice(0, 3).forEach((faq, index) => {
                    response += `**${index + 1}. ${faq.question}**\n`;
                    response += `${faq.answer.length > 200 ? faq.answer.substring(0, 200) + '...' : faq.answer}\n`;
                    response += `📂 *${faq.category}*\n\n`;
                });
            }

            return {
                type: 'faq_answer',
                message: response,
                suggestions: this.generateSuggestions(faqs),
                faqs: faqs.map(faq => ({
                    id: faq._id,
                    question: faq.question,
                    answer: faq.answer,
                    category: faq.category
                }))
            };
        }

        // Fallback response khi không có thông tin phù hợp
        return {
            type: 'no_result',
            message: "🤔 **Tôi chưa hiểu rõ câu hỏi của bạn. Bạn có thể hỏi cụ thể hơn được không?**\n\n" +
                    "� **Ví dụ các câu hỏi tôi có thể trả lời:**\n" +
                    "• \"Giá khóa học tiếng Hàn bao nhiêu?\"\n" +
                    "• \"Lịch học các lớp như thế nào?\"\n" +
                    "• \"Thông tin về giảng viên?\"\n" +
                    "• \"Làm sao để đăng ký học?\"\n\n" +
                    "� **Hãy hỏi câu hỏi cụ thể để tôi có thể hỗ trợ bạn tốt nhất!**",
            suggestions: [
                "💰 Học phí các khóa học?",
                "📅 Lịch học như thế nào?", 
                "👨‍🏫 Thông tin giảng viên?",
                "🎓 Cách đăng ký học?",
                "👥 Sĩ số lớp học?",
                "📝 Cách nộp bài tập?"
            ]
        };
    }

    // Tạo gợi ý câu hỏi dựa trên hệ thống Korea_DB thực tế
    generateSuggestions(faqs) {
        const suggestions = [
            "💰 Giá các khóa học từ bao nhiêu?",
            "📅 Lịch học các lớp trong tuần?",
            "📝 Làm sao để nộp bài tập?",
            "👨‍🏫 Thông tin về giảng viên lớp?",
            "📊 Hệ thống chấm điểm như thế nào?",
            "🎓 Cách đăng ký tham gia lớp học?",
            "👥 Có bao nhiêu học viên trong lớp?",
            "⏰ Thời gian bắt đầu và kết thúc khóa?",
            "📋 Bài tập có thời hạn nộp không?",
            "🔍 Cách theo dõi tiến độ học tập?",
            "🆕 Muốn đăng ký tài khoản mới?",
            "💳 Có thể trả góp học phí không?",
            "📞 Thông tin liên hệ tư vấn?",
            "🏆 Chứng chỉ sau khi hoàn thành?",
            "📱 Cách sử dụng hệ thống học online?",
            "🇰🇷 Các khóa học tiếng Hàn nào phù hợp?"
        ];

        // Lấy random 4 suggestions
        const shuffled = suggestions.sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 4);
    }

    // Main method xử lý message
    async handleMessage(message) {
        try {
            console.log('🔍 [DEBUG] Received message:', message);
            
            // Đảm bảo message là string
            if (typeof message !== 'string' || !message.trim()) {
                console.log('⚠️ [DEBUG] Invalid message parameter');
                return {
                    success: true,
                    data: {
                        type: 'error',
                        message: "Vui lòng nhập câu hỏi của bạn! 🤔",
                        suggestions: this.generateSuggestions([])
                    }
                };
            }

            // Phân tích intent
            console.log('🔍 [DEBUG] Analyzing intent...');
            const intent = this.analyzeIntent(message);
            console.log('🔍 [DEBUG] Intent analyzed:', intent);
            
            // Tìm kiếm FAQ và thông tin thực tế
            console.log('🔍 [DEBUG] Searching FAQ...');
            const { faqs, realData } = await this.searchFAQ(message, intent);
            console.log('🔍 [DEBUG] Search results:', { faqCount: faqs?.length, hasRealData: !!realData });
            
            // Tạo response
            console.log('🔍 [DEBUG] Generating response...');
            const response = this.generateResponse(faqs, intent, message, realData);
            console.log('🔍 [DEBUG] Response generated:', response.type);
            
            return {
                success: true,
                data: response
            };
        } catch (error) {
            console.error('❌ [ERROR] Detailed error in handleMessage:', {
                message: error.message,
                stack: error.stack,
                input: message
            });
            return {
                success: false,
                data: {
                    type: 'error',
                    message: "Xin lỗi, có lỗi xảy ra. Vui lòng thử lại! 😅",
                    suggestions: this.generateSuggestions([])
                }
            };
        }
    }

    // Method để lấy FAQ theo category
    async getFAQsByCategory(category) {
        try {
            return await FAQ.find({ 
                category: category, 
                isActive: true 
            }).sort({ priority: -1, viewCount: -1 });
        } catch (error) {
            console.error('Error getting FAQs by category:', error);
            return [];
        }
    }

    // Method để lấy FAQ phổ biến
    async getPopularFAQs(limit = 5) {
        try {
            return await FAQ.find({ 
                isActive: true 
            }).sort({ viewCount: -1, priority: -1 }).limit(limit);
        } catch (error) {
            console.error('Error getting popular FAQs:', error);
            return [];
        }
    }
}

module.exports = new FAQChatbot();
